# Mars Teraformace – zdroj herních pravidel

Tento balíček obsahuje zdroj použitý pro sestavení prohlížečové knihovny `mars-rules.js`. Herní logiku vytvořili přispěvatelé projektu Terraforming Mars Open-source. Původní autor deskové hry je Jacob Fryxelius, vydavatel FryxGames.

- [Zdrojová revize z 31. července 2020](https://github.com/terraforming-mars/terraforming-mars/tree/680d9fcb861f183eae201f800a26a5836ba03ac2)
- Licenční podmínky jsou v souboru `LICENSE` (GNU GPL verze 3).
- Prohlížečová úprava vznikla 22. listopadu 2026. Zahrnuje lokální uložení rozhodnutí, oddělené pohledy hráčů, validaci plateb a strojově dostupný katalog. Hra obnovuje zamíchání karet i nevyřízené volby z uloženého semínka a průběhu partie. Žádný databázový server není ke hře potřeba.
- Sólová příprava odhalí čtyři projekty pro umístění neutrálních dílků podle tištěných pravidel. Promokarta X09 je vyřazena ze sady Neklid.

## Sestavení

Použijte esbuild 0.25.12. Při jeho dostupnosti v `PATH` ve složce s tímto souborem spusťte `sh build.sh`. Volitelný první argument určuje výstupní soubor. Proměnná `ESBUILD` dovoluje určit cestu k vlastní kopii esbuild. Herní knihovna nemá další závislosti za běhu.

V prohlížeči načtěte sestavený soubor jako obyčejný skript. Globální rozhraní `MarsRules` má metody `create`, `view`, `choose`, `save`, `restore`, `cards` a `definition`. `revision` označuje původní zdrojovou revizi. Zachycené herní stavy zůstanou funkční s knihovnou této verze.

```javascript
const session = MarsRules.create({
  players: [{id: 'ada', name: 'Ada'}, {id: 'petr', name: 'Petr'}],
  options: {corporateEra: true, prelude: false, venus: false, colonies: false, turmoil: false},
});
const view = MarsRules.view(session, 'ada');
const choices = view.waitingFor.options;
MarsRules.choose(session, 'ada', [[choices[0].cards[0].name], []], view.revision);
const restored = MarsRules.restore(MarsRules.save(session));
```

`view` vrací osobní nabídku, ruku, veřejné vyložené karty a stav mapy. `save` je soukromý stav hostitele s pořadím karet a volbami všech hráčů. `choose` vrací číslo nově přijatého rozhodnutí. Jeho čtvrtý argument umožňuje zkontrolovat, že hráč odpovídá na poslední nabídku.
