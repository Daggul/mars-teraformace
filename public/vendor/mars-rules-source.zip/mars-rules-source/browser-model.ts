// Browser view model adapted from this revision’s server.ts, 2026-11-22. GPL-3.0.
import {AndOptions} from './src/inputs/AndOptions';
import { CardModel } from './src/models/CardModel';
import {ColonyModel} from './src/models/ColonyModel';
import {Color} from './src/Color';
import { Game, GameOptions } from './src/Game';
import {ICard} from './src/cards/ICard';
import {IProjectCard} from './src/cards/IProjectCard';
import {ISpace} from './src/ISpace';
import {OrOptions} from './src/inputs/OrOptions';
import {Player} from './src/Player';
import {PlayerInput} from './src/PlayerInput';
import {PlayerInputModel} from './src/models/PlayerInputModel';
import {PlayerInputTypes} from './src/PlayerInputTypes';
import {PlayerModel} from './src/models/PlayerModel';
import {SelectAmount} from './src/inputs/SelectAmount';
import {SelectCard} from './src/inputs/SelectCard';
import {SelectHowToPay} from './src/inputs/SelectHowToPay';
import {SelectHowToPayForCard} from './src/inputs/SelectHowToPayForCard';
import {SelectPlayer} from './src/inputs/SelectPlayer';
import {SelectSpace} from './src/inputs/SelectSpace';
import {SpaceModel} from './src/models/SpaceModel';
import {TileType} from './src/TileType';
import { Phase } from './src/Phase';
import { Resources } from "./src/Resources";
import { CardType } from './src/cards/CardType';
import { ClaimedMilestoneModel, IMilestoneScore } from "./src/models/ClaimedMilestoneModel";
import { FundedAwardModel, IAwardScore } from "./src/models/FundedAwardModel";
import { PartyModel, DelegatesModel, TurmoilModel } from './src/models/TurmoilModel';
import { SelectDelegate } from './src/inputs/SelectDelegate';

function getMilestones(game: Game): Array<ClaimedMilestoneModel> {
  const allMilestones = game.milestones;
  const claimedMilestones = game.claimedMilestones;
  let milestoneModels: Array<ClaimedMilestoneModel> = [];

  for (let idx in allMilestones) {
    let claimed = claimedMilestones.find((m) => m.milestone.name === allMilestones[idx].name);
    let scores:Array<IMilestoneScore> =  [];
    if (claimed === undefined && claimedMilestones.length < 3) {
      game.getPlayers().forEach(player => {
        scores.push({
          playerColor: player.color,
          playerScore: allMilestones[idx].getScore(player, game)
        });
      });
    }

    milestoneModels.push({
      player_name: claimed === undefined ? "": claimed.player.name,
      player_color: claimed === undefined ? "": claimed.player.color,
      milestone: allMilestones[idx],
      scores
    });
  }
  
  return milestoneModels;
}

function getAwards(game: Game): Array<FundedAwardModel>  {
  const allAwards = game.awards;
  const fundedAwards = game.fundedAwards;
  let awardModels: Array<FundedAwardModel> = [];

  for (let idx in allAwards) {
    let funded = fundedAwards.find((a) => a.award.name === allAwards[idx].name);
    let scores:Array<IAwardScore> =  [];
    if (fundedAwards.length < 3 || funded !== undefined) {
      game.getPlayers().forEach(player => {
        scores.push({
          playerColor: player.color,
          playerScore: allAwards[idx].getScore(player, game)
        });
      });
    }

    awardModels.push({
      player_name: funded === undefined ? "": funded.player.name,
      player_color: funded === undefined ?  "": funded.player.color,
      award: allAwards[idx],
      scores: scores
    })
  }
  
  return awardModels;
}

function getCorporationCard(player: Player): CardModel | undefined {
  if (player.corporationCard == undefined) return undefined;

  return ({
    name: player.corporationCard.name,
    resources: player.getResourcesOnCard(player.corporationCard),
    calculatedCost: 0,
    cardType: CardType.CORPORATION
  }) as CardModel
}

export function playerView(player: Player, game: Game) {
  const output = {
    cardsInHand: getCards(player, player.cardsInHand, game, false),
    draftedCards: getCards(player, player.draftedCards, game, false),
    milestones: getMilestones(game),
    awards: getAwards(game),
    cardCost: player.cardCost,
    color: player.color,
    corporationCard: getCorporationCard(player),
    energy: player.energy,
    energyProduction: player.getProduction(Resources.ENERGY),
    generation: game.getGeneration(),
    heat: player.heat,
    heatProduction: player.getProduction(Resources.HEAT),
    id: player.id,
    megaCredits: player.megaCredits,
    megaCreditProduction: player.getProduction(Resources.MEGACREDITS),
    name: player.name,
    oceans: game.board.getOceansOnBoard(),
    oxygenLevel: game.getOxygenLevel(),
    phase: game.phase,
    plants: player.plants,
    plantProduction: player.getProduction(Resources.PLANTS),
    playedCards: getCards(player, player.playedCards, game),
    cardsInHandNbr: player.cardsInHand.length,
    players: getPlayers(game.getPlayers(), game),
    spaces: getSpaces(game.board.spaces),
    steel: player.steel,
    steelProduction: player.getProduction(Resources.STEEL),
    steelValue: player.steelValue,
    temperature: game.getTemperature(),
    terraformRating: player.getTerraformRating(),
    titanium: player.titanium,
    titaniumProduction: player.getProduction(Resources.TITANIUM),
    titaniumValue: player.getTitaniumValue(game),
    victoryPointsBreakdown: player.getVictoryPoints(game),
    waitingFor: getWaitingFor(player.getWaitingFor(), player, game),
    gameLog: game.gameLog,
    isSoloModeWin: game.isSoloModeWin(),
    gameAge: game.gameAge,
    isActive: player.id === game.activePlayer,
    corporateEra: game.corporateEra,
    venusNextExtension: game.venusNextExtension,
    venusScaleLevel: game.getVenusScaleLevel(),
    boardName: game.boardName,
    colonies: getColonies(game),
    tags: player.getAllTags(),
    showOtherPlayersVP: game.showOtherPlayersVP,
    actionsThisGeneration: Array.from(player.getActionsThisGeneration()),
    fleetSize: player.fleetSize,
    tradesThisTurn: player.tradesThisTurn,
    turmoil: getTurmoil(game),
    selfReplicatingRobotsCards: player.getSelfReplicatingRobotsCards(game),
    dealtCorporationCards: player.dealtCorporationCards,
    dealtPreludeCards: player.dealtPreludeCards,
    initialDraft: game.initialDraft,
    needsToDraft: player.needsToDraft,
    deckSize: game.dealer.getDeckSize(),
    randomMA: game.randomMA
  } as PlayerModel;
  return output;
}

function getCardsAsCardModel(cards: Array<ICard>, player: Player, game: Game, showResouces: boolean = true): Array<CardModel> {
  let result:Array<CardModel> = [];

  cards.forEach((card) => {
    result.push({name: card.name, resources: (card.resourceCount !== undefined && showResouces ? card.resourceCount : undefined), calculatedCost: (card as IProjectCard).cost == null ? 0 : player.getCardCost(game,card as IProjectCard), cardType: (card as IProjectCard).cardType || CardType.CORPORATION});
  });

  return result;
}

function getWaitingFor(
    waitingFor: PlayerInput | undefined, player: Player, game: Game
): PlayerInputModel | undefined {
  if (waitingFor === undefined) {
    return undefined;
  }
  const result: PlayerInputModel = {
    title: waitingFor.title,
    inputType: waitingFor.inputType,
    amount: undefined,
    options: undefined,
    cards: undefined,
    maxCardsToSelect: undefined,
    minCardsToSelect: undefined,
    canUseSteel: undefined,
    canUseTitanium: undefined,
    canUseHeat: undefined,
    players: undefined,
    availableSpaces: undefined,
    max: undefined,
    microbes: undefined,
    floaters: undefined
  };
  switch (waitingFor.inputType) {
    case PlayerInputTypes.AND_OPTIONS:
    case PlayerInputTypes.OR_OPTIONS:
      result.options = [];
      for (const option of (waitingFor as AndOptions | OrOptions).options) {
        const subOption = getWaitingFor(option, player, game);
        if (subOption !== undefined) {
          result.options.push(subOption);
        }
      }
      break;
    case PlayerInputTypes.SELECT_HOW_TO_PAY_FOR_CARD:
      result.cards = getCardsAsCardModel((waitingFor as SelectHowToPayForCard).cards, player, game, false);
      result.microbes = (waitingFor as SelectHowToPayForCard).microbes;
      result.floaters = (waitingFor as SelectHowToPayForCard).floaters;
      result.canUseHeat = (waitingFor as SelectHowToPayForCard).canUseHeat;
      break;
    case PlayerInputTypes.SELECT_CARD:
      result.cards = getCardsAsCardModel((waitingFor as SelectCard<ICard>).cards, player, game);
      result.maxCardsToSelect = (waitingFor as SelectCard<ICard>)
          .maxCardsToSelect;
      result.minCardsToSelect = (waitingFor as SelectCard<ICard>)
          .minCardsToSelect;
      break;
    case PlayerInputTypes.SELECT_HOW_TO_PAY:
      result.amount = (waitingFor as SelectHowToPay).amount;
      result.canUseSteel = (waitingFor as SelectHowToPay).canUseSteel;
      result.canUseTitanium = (waitingFor as SelectHowToPay).canUseTitanium;
      result.canUseHeat = (waitingFor as SelectHowToPay).canUseHeat;
      break;
    case PlayerInputTypes.SELECT_PLAYER:
      result.players = (waitingFor as SelectPlayer)
          .players.map((player) => player.id);
      break;
    case PlayerInputTypes.SELECT_SPACE:
      result.availableSpaces = (waitingFor as SelectSpace)
          .availableSpaces.map((space) => space.id);
      break;
    case PlayerInputTypes.SELECT_AMOUNT:
      result.max = (waitingFor as SelectAmount).max;
      break;
    case PlayerInputTypes.SELECT_DELEGATE:
      result.players = (waitingFor as SelectDelegate)
          .players.map((player) => {
            if(player === "NEUTRAL") {
              return "NEUTRAL";
            }  
            else {
              return player.id;
            }
          });
      break;
  }
  return result;
}

function getCards(
    player: Player,
    cards: Array<IProjectCard>,
    game: Game,
    showResouces: boolean = true
): Array<CardModel> {
  return cards.map((card) => ({
    resources: showResouces?player.getResourcesOnCard(card):undefined,
    name: card.name,
    calculatedCost: player.getCardCost(game, card),
    cardType: card.cardType
  }));
}

function getPlayers(players: Array<Player>, game: Game): Array<PlayerModel> {
  return players.map((player) => {
    return {
      color: player.color,
      corporationCard: getCorporationCard(player),
      energy: player.energy,
      energyProduction: player.getProduction(Resources.ENERGY),
      heat: player.heat,
      heatProduction: player.getProduction(Resources.HEAT),
      id: player.id,
      megaCredits: player.megaCredits,
      megaCreditProduction: player.getProduction(Resources.MEGACREDITS),
      name: player.name,
      plants: player.plants,
      plantProduction: player.getProduction(Resources.PLANTS),
      playedCards: getCards(player, player.playedCards, game),
      cardsInHandNbr: player.cardsInHand.length,
      steel: player.steel,
      steelProduction: player.getProduction(Resources.STEEL),
      steelValue: player.steelValue,
      terraformRating: player.getTerraformRating(),
      titanium: player.titanium,
      titaniumProduction: player.getProduction(Resources.TITANIUM),
      titaniumValue: player.getTitaniumValue(game),
      victoryPointsBreakdown: player.getVictoryPoints(game),
      isActive: player.id === game.activePlayer,
      venusNextExtension: game.venusNextExtension,
      venusScaleLevel: game.getVenusScaleLevel(),
      boardName: game.boardName,
      colonies: getColonies(game),
      tags: player.getAllTags(),
      showOtherPlayersVP: game.showOtherPlayersVP,
      actionsThisGeneration: Array.from(player.getActionsThisGeneration()),
      fleetSize: player.fleetSize,
      tradesThisTurn: player.tradesThisTurn,
      turmoil: getTurmoil(game),
      selfReplicatingRobotsCards: player.getSelfReplicatingRobotsCards(game),
      needsToDraft: player.needsToDraft,
      deckSize: game.dealer.getDeckSize()
    } as PlayerModel;
  });
}

function getColonies(game: Game): Array<ColonyModel> {
  return game.colonies.map((colony): ColonyModel => ({
      colonies: colony.colonies.map((playerId): Color => game.getPlayerById(playerId).color),
      isActive: colony.isActive,
      name: colony.name,
      trackPosition: colony.trackPosition,
      visitor: colony.visitor === undefined ? undefined : game.getPlayerById(colony.visitor).color
  }));
}

function getTurmoil(game: Game): TurmoilModel | undefined {
  if (game.turmoilExtension && game.turmoil){
    const parties = getParties(game);
    let chairman, dominant, ruling;
    if (game.turmoil.chairman){
      if (game.turmoil.chairman === "NEUTRAL") {
        chairman = Color.NEUTRAL;
      }
      else {
        chairman = game.getPlayerById(game.turmoil.chairman).color;
      }
    }
    if (game.turmoil.dominantParty){
      dominant = game.turmoil.dominantParty.name;
    }
    if (game.turmoil.rulingParty){
      ruling = game.turmoil.rulingParty.name;
    }

    const lobby = Array.from(game.turmoil.lobby, player => game.getPlayerById(player).color);

    const reserve = game.turmoil.getPresentPlayers().map(player => {
      const number = game.turmoil!.getDelegates(player);
      if (player != "NEUTRAL") {
        return {color: game.getPlayerById(player).color, number: number};
      }
      else {
        return {color: Color.NEUTRAL, number: number};
      } 
    });

    let distant;
    if (game.turmoil.distantGlobalEvent) {
      distant = {
        name: game.turmoil.distantGlobalEvent.name, 
        description: game.turmoil.distantGlobalEvent.description,
        revealed: game.turmoil.distantGlobalEvent.revealedDelegate, 
        current: game.turmoil.distantGlobalEvent.currentDelegate
      };
    }

    let comming;
    if (game.turmoil.commingGlobalEvent) {
      comming = {
        name: game.turmoil.commingGlobalEvent.name, 
        description: game.turmoil.commingGlobalEvent.description,
        revealed: game.turmoil.commingGlobalEvent.revealedDelegate, 
        current: game.turmoil.commingGlobalEvent.currentDelegate}
      ;
    }

    let current;
    if (game.turmoil.currentGlobalEvent) {
      current = {
        name: game.turmoil.currentGlobalEvent.name, 
        description: game.turmoil.currentGlobalEvent.description,
        revealed: game.turmoil.currentGlobalEvent.revealedDelegate, 
        current: game.turmoil.currentGlobalEvent.currentDelegate
      };
    }

    return {
      chairman: chairman, 
      ruling: ruling, 
      dominant: dominant, 
      parties: parties, 
      lobby: lobby, 
      reserve: reserve, 
      distant: distant,
      comming: comming,
      current: current
    };
  }
  else {
    return undefined;
  }

}

function getParties(game: Game): Array<PartyModel> | undefined{
  if (game.turmoilExtension && game.turmoil){
    return game.turmoil.parties.map(function(party) {
      let delegates = new Array<DelegatesModel>();
      party.getPresentPlayers().forEach(player => {
        const number = party.getDelegates(player);
        if (player != "NEUTRAL") {
          delegates.push({color: game.getPlayerById(player).color, number: number});
        }
        else {
          delegates.push({color: Color.NEUTRAL, number: number});
        }
      });
      let partyLeader;
      if (party.partyLeader) {
        if (party.partyLeader === "NEUTRAL") {
          partyLeader = Color.NEUTRAL;
        }
        else {
          partyLeader = game.getPlayerById(party.partyLeader).color;
        }
      }
      return {
        name: party.name, 
        description: party.description, 
        partyLeader: partyLeader, 
        delegates: delegates
      };
    });
  }
  else {
    return undefined;
  }
}

// Oceans can't be owned so they shouldn't have a color associated with them
// Land claim can have a color on a space without a tile
function getColor(space: ISpace): Color | undefined {
  if (
    (space.tile === undefined || space.tile.tileType !== TileType.OCEAN) &&
    space.player !== undefined) {
    return space.player.color;
  }
  return undefined;
}

function getSpaces(spaces: Array<ISpace>): Array<SpaceModel> {
  return spaces.map((space) => {
    return {
      x: space.x,
      y: space.y,
      id: space.id,
      bonus: space.bonus,
      spaceType: space.spaceType,
      tileType: space.tile && space.tile.tileType,
      color: getColor(space)
    };
  });
}

