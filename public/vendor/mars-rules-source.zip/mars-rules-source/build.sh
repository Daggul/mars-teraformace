#!/bin/sh
set -eu
cd "$(dirname "$0")"
"${ESBUILD:-esbuild}" entry.ts --bundle --format=iife --global-name=MarsRules --platform=browser --target=es2020 --charset=utf8 --minify --inject:./environment.ts --define:Math.random=rulesRandom --define:Date.now=rulesNow --banner:js='/*! Mars Teraformace rules. Copyright Terraforming Mars open-source contributors. GPL-3.0. Browser port 2026-11-22. See the accompanying source and LICENSE. */' --outfile="${1:-../mars-rules.js}"
