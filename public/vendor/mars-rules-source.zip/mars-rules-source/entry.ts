// Browser adapter for the Terraforming Mars rules engine, 2026-11-22. GPL-3.0.
import {Game} from './src/Game';
import {Player} from './src/Player';
import {Color} from './src/Color';
import {CardType} from './src/cards/CardType';
import {BoardName} from './src/BoardName';
import {PlayerInputTypes as Kind} from './src/PlayerInputTypes';
import {BeginnerCorporation} from './src/cards/corporation/BeginnerCorporation';
import * as decks from './src/Dealer';
import {playerView} from './browser-model';
import {withinRules, rulesRandom, RuleClock} from './environment';

export const revision = '680d9fcb861f183eae201f800a26a5836ba03ac2';
const colors = [Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.BLACK];
type Seat = {id: string; name: string; beginner?: boolean; color?: Color};
type Options = {corporateEra?: boolean; prelude?: boolean; colonies?: boolean; venus?: boolean; turmoil?: boolean; draft?: boolean; board?: BoardName; solarPhase?: boolean};
type Config = {players: Seat[]; options?: Options; seed?: number; firstPlayer?: string; created?: number};
type Wire = string[][];
type Turn = {player: string; response: Wire; time: number};
type Saved = {version: 1; config: Config; history: Turn[]};
type Session = {config: Config; game: Game; clock: RuleClock; history: Turn[]};
const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value));
function insist(ok: unknown, message: string): asserts ok { if (!ok) throw Error(message); }
const moneyKeys = ['megaCredits', 'steel', 'titanium', 'heat', 'microbes', 'floaters'] as const;

export function create(config: Config): Session {
  insist(config && Array.isArray(config.players) && config.players.length >= 1 && config.players.length <= 5, 'Stůl potřebuje jednoho až pět hráčů.');
  const ids = new Set<string>();
  const freeColors = new Set(colors);
  const seats = config.players.map(seat => {
    insist(typeof seat.id === 'string' && seat.id.length > 0 && seat.id.length <= 128 && !ids.has(seat.id), 'Každý hráč potřebuje vlastní místo.');
    insist(typeof seat.name === 'string' && seat.name.trim().length > 0, 'Vyplň jméno hráče.');
    ids.add(seat.id);
    const color = seat.color && freeColors.has(seat.color) ? seat.color : freeColors.values().next().value!;
    freeColors.delete(color);
    return {id: seat.id, name: seat.name.trim().slice(0,64), beginner: !!seat.beginner, color};
  });
  const options = clone(config.options || {});
  const seed = config.seed === undefined ? crypto.getRandomValues(new Uint32Array(1))[0] : Number(config.seed) >>> 0;
  const created = Number.isFinite(config.created) ? config.created! : new Date().getTime();
  const recorded = {players: seats, options, seed, created, firstPlayer: ids.has(config.firstPlayer!) ? config.firstPlayer : undefined};
  const clock = {state: seed, time: created};
  const game = withinRules(clock, () => {
    const players = seats.map(seat => { const player = new Player(seat.name, seat.color, seat.beginner); player.id = seat.id; return player; });
    const first = players.find(p => p.id === recorded.firstPlayer) || players[Math.floor(rulesRandom() * players.length)];
    return new Game('mars-'+seed.toString(36), players, first, {
      corporateEra: players.length === 1 || !!options.corporateEra,
      preludeExtension: !!options.prelude, venusNextExtension: !!options.venus, coloniesExtension: !!options.colonies, turmoilExtension: !!options.turmoil,
      draftVariant: !!options.draft && players.length > 1, initialDraftVariant: false, randomMA: false,
      boardName: Object.values(BoardName).includes(options.board!) ? options.board! : BoardName.ORIGINAL,
      showOtherPlayersVP: true, solarPhaseOption: options.solarPhase === undefined ? !!options.venus : !!options.solarPhase,
      customCorporationsList: [], shuffleMapOption: false, promoCardsOption: false, undoOption: false,
      includeVenusMA: true, startingCorporations: 2, soloTR: false, clonedGamedId: undefined,
    });
  });
  return {game, clock, config: recorded, history: []};
}

export function view(session: Session, id: string) {
  const game = session.game;
  const player = game.getPlayerById(id);
  insist(player, 'Toto místo u stolu neexistuje.');
  const v: any = playerView(player, game);
  v.revision = session.history.length;
  v.activePlayer = game.activePlayer;
  v.firstPlayer = game.getPlayers()[0].id;
  v.options = session.config.options;
  v.solo = session.config.players.length === 1;
  v.hasPassed = game.hasPassedThisActionPhase(player);
  v.players.forEach((other: any) => {
    const seat = game.getPlayerById(other.id);
    other.hasPassed = game.hasPassedThisActionPhase(seat);
    other.hasInput = !!seat.getWaitingFor();
  });
  return clone(v);
}

function parsePay(text: string, node: any, player: Player, game: Game, card?: any) {
  let data: any;
  try { data = JSON.parse(text); } catch { throw Error('Platba má nesprávný formát.'); }
  insist(data && typeof data === 'object' && !Array.isArray(data), 'Platba má nesprávný formát.');
  const pay: Record<string, number> = {};
  for (const key of moneyKeys) {
    const number = data[key] === undefined ? 0 : data[key];
    insist(Number.isSafeInteger(number) && number >= 0, 'Množství placených zdrojů musí být celé nezáporné číslo.');
    pay[key] = number;
  }
  const limits: Record<string, number> = {
    megaCredits: player.megaCredits,
    steel: (card ? card.tags.includes('building') : node.canUseSteel) ? player.steel : 0,
    titanium: (card ? card.tags.includes('space') : node.canUseTitanium) ? player.titanium : 0,
    heat: node.canUseHeat ? player.heat : 0,
    microbes: card?.tags.includes('plant') ? node.microbes || 0 : 0,
    floaters: card?.tags.includes('venus') ? node.floaters || 0 : 0,
  };
  for (const key of moneyKeys) insist(pay[key] <= limits[key], 'Pro tuto platbu nemáš dost povolených zdrojů.');
  const value = pay.megaCredits + pay.heat + pay.steel * player.steelValue + pay.titanium * player.getTitaniumValue(game) + pay.microbes * 2 + pay.floaters * 3;
  insist(value >= (card ? player.getCardCost(game,card) : node.amount), 'Zvolená platba nepokrývá cenu.');
  return JSON.stringify(pay);
}

function validateRow(row: string[], node: any, player: Player, game: Game): string[] {
  switch (node.inputType) {
    case Kind.OR_OPTIONS: {
      const index = Number(row[0]);
      insist(row.length && /^(0|[1-9]\d*)$/.test(row[0]) && node.options[index], 'Zvol dostupnou akci.');
      return [String(index),...validateRow(row.slice(1),node.options[index],player,game)];
    }
    case Kind.SELECT_AMOUNT:
      insist(row.length === 1 && /^(0|[1-9]\d*)$/.test(row[0]) && Number(row[0]) <= node.max, 'Zvol přípustné množství.');
      return row;
    case Kind.SELECT_CARD:
      insist(row.length >= node.minCardsToSelect && row.length <= node.maxCardsToSelect && new Set(row).size === row.length && row.every(name => node.cards.some((card: any) => card.name === name)), 'Výběr karet neodpovídá nabídce.');
      return row;
    case Kind.SELECT_HOW_TO_PAY:
      insist(row.length === 1, 'Zadej platbu.');
      return [parsePay(row[0],node,player,game)];
    case Kind.SELECT_HOW_TO_PAY_FOR_CARD: {
      const card = node.cards.find((c: any) => c.name === row[0]);
      insist(row.length === 2 && card, 'Vyber hratelnou kartu z ruky.');
      return [row[0],parsePay(row[1],node,player,game,card)];
    }
    case Kind.SELECT_OPTION:
      insist(row.length === 0 || (row.length === 1 && row[0] === ''), 'Akce nevyžaduje další volbu.');
      return [];
    case Kind.SELECT_SPACE:
      insist(row.length === 1 && node.availableSpaces.some((space: any) => space.id === row[0]), 'Vyber zvýrazněné pole.');
      return row;
    case Kind.SELECT_DELEGATE:
    case Kind.SELECT_PLAYER:
      insist(row.length === 1 && node.players.some((p: any) => (p === 'NEUTRAL' ? p : p.id) === row[0]), 'Vyber hráče z nabídky.');
      return row;
    default: throw Error('Tuto volbu nelze vyhodnotit.');
  }
}

function validate(response: Wire, node: any, player: Player, game: Game): Wire {
  insist(Array.isArray(response) && response.length <= 12 && response.every(row => Array.isArray(row) && row.length <= 200 && row.every(val => typeof val === 'string' && val.length <= 1000)), 'Neplatný formát tahu.');
  if (node.inputType !== Kind.AND_OPTIONS) {
    insist(response.length === 1, 'Zvol jednu akci.');
    return [validateRow(response[0],node,player,game)];
  }
  insist(response.length === node.options.length, 'Vyplň všechny volby.');
  const wire = response.map((row,i) => validateRow(row,node.options[i],player,game));
  const corpIndex = node.options.findIndex((x: any) => x.title === 'Select corporation');
  if (corpIndex >= 0) {
    const corp = node.options[corpIndex].cards.find((c: any) => c.name === wire[corpIndex][0]);
    const buy = node.options.findIndex((x: any) => x.title === 'Select initial cards to buy');
    const price = corp.name === 'Terralabs Research' ? 1 : corp.name === 'Polyphemos' ? 5 : player.cardCost;
    insist(buy >= 0 && wire[buy].length * price <= corp.startingMegaCredits, 'Vybrané projekty překračují počáteční rozpočet korporace.');
  }
  const heatPay = node.options.findIndex((x: any) => x.title === 'Select how to pay for cards');
  if (heatPay >= 0) {
    const buy = node.options.findIndex((x: any) => x.title === 'Select which cards to take into hand');
    if (buy >= 0) {
      const price = wire[buy].length * player.cardCost;
      const heat = JSON.parse(wire[heatPay][0]).heat;
      insist(price - Math.min(price,heat) <= player.megaCredits, 'Zbývající megakredity nepokryjí výzkum.');
    }
  }
  return wire;
}

function applyTurn(session: Session, id: string, response: Wire, time: number) {
  const player = session.game.getPlayerById(id);
  const decision = player?.getWaitingFor();
  insist(player && decision, 'Na tuto volbu je nyní na tahu jiný hráč.');
  const wire = validate(response,decision,player,session.game);
  session.clock.time = time;
  withinRules(session.clock, () => player.process(session.game,wire));
  session.history.push({player:id, response:clone(wire), time});
}

export function choose(session: Session, id: string, response: Wire, expectedRevision?: number) {
  if (expectedRevision !== undefined) insist(expectedRevision === session.history.length, 'Stůl se mezitím změnil. Ověř aktuální nabídku.');
  try { applyTurn(session,id,response,new Date().getTime()); }
  catch (error) {
    // An upstream callback can reject after partially applying a composite action.
    // Rebuilding the accepted event stream restores pending callbacks as well as resources.
    const restored = restore(save(session));
    Object.assign(session,restored);
    throw error;
  }
  return session.history.length;
}
export function save(session: Session): Saved { return clone({version:1,config:session.config,history:session.history}); }
export function restore(snapshot: Saved): Session {
  insist(snapshot?.version === 1 && Array.isArray(snapshot.history), 'Tuto uloženou partii nelze načíst.');
  const session = create(snapshot.config);
  for (const event of snapshot.history) applyTurn(session,event.player,event.response,event.time);
  return session;
}

const groups: [string, any[]][] = [
  ['base',decks.ALL_PROJECT_CARDS], ['corporate',decks.ALL_CORP_ERA_PROJECT_CARDS],
  ['base',decks.ALL_CORPORATION_CARDS], ['corporate',decks.ALL_CORP_ERA_CORPORATION_CARDS],
  ['base',[{factory:BeginnerCorporation}]],
  ['prelude',decks.ALL_PRELUDE_CARDS], ['prelude',decks.ALL_PRELUDE_PROJECTS_CARDS], ['prelude',decks.ALL_PRELUDE_CORPORATIONS],
  ['venus',decks.ALL_VENUS_PROJECTS_CARDS], ['venus',decks.ALL_VENUS_CORPORATIONS],
  ['colonies',decks.ALL_COLONIES_PROJECTS_CARDS], ['colonies',decks.ALL_COLONIES_CORPORATIONS],
  ['turmoil',decks.ALL_TURMOIL_PROJECTS_CARDS], ['turmoil',decks.ALL_TURMOIL_CORPORATIONS],
];
const catalog = new Map<string, any>();
for (const [expansion,group] of groups) for (const {factory} of group) {
  const card = new factory();
  catalog.set(card.name,{name:card.name,expansion,cardType:card.cardType || CardType.CORPORATION,tags:card.tags,cost:card.cost,startingMegaCredits:card.startingMegaCredits,resourceType:card.resourceType,hasAction:typeof card.action === 'function'});
}
export function definition(name: string) { const card=catalog.get(name); return card && clone(card); }
export function cards() { return clone(Array.from(catalog.values())); }
