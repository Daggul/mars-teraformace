// Browser replay adapter, 2026-11-22. GPL-3.0.
export interface RuleClock { state: number; time: number }
let current: RuleClock | undefined;
export function withinRules<T>(clock: RuleClock, body: () => T): T {
  const previous = current;
  current = clock;
  try { return body(); } finally { current = previous; }
}
export function rulesRandom() {
  if (!current) throw Error('The random generator needs an active game');
  current.state = (current.state + 0x6d2b79f5) >>> 0;
  let v = current.state;
  v = Math.imul(v ^ (v >>> 15), v | 1);
  v ^= v + Math.imul(v ^ (v >>> 7), v | 61);
  return ((v ^ (v >>> 14)) >>> 0) / 4294967296;
}
export function rulesNow() { return current?.time ?? 0; }
