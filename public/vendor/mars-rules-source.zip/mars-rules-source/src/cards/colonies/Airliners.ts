import { IProjectCard } from "../IProjectCard";
import { Tags } from "../Tags";
import { CardType } from '../CardType';
import { Player } from "../../Player";
import { CardName } from '../../CardName';
import { Resources } from "../../Resources";
import { ResourceType } from '../../ResourceType';
import { Game } from '../../Game';

export class Airliners implements IProjectCard {
    public cost: number = 11;
    public tags: Array<Tags> = [];
    public name: CardName = CardName.AIRLINERS;
    public cardType: CardType = CardType.AUTOMATED;

    public canPlay(player: Player): boolean {
        return player.getResourceCount(ResourceType.FLOATER) >= 3;
    }

    public play(player: Player, game: Game) {
      player.setProduction(Resources.MEGACREDITS, 2);
      game.addResourceInterrupt(player, ResourceType.FLOATER, 2, undefined);
      return undefined;
    }
    public getVictoryPoints() {
        return 1;
    }
}

